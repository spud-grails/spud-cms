package spud.core;

// This annotation allows role level restrictions to be applied in a decoupled manner, Check the spud.core.SecurityFilters and spud.core.SecurityService for more info
public @interface SpudSecure {
	String [] value();
}
