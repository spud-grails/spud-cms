class SpudCoreUrlMappings {

	static mappings = {
        '/spud/admin' {
            controller = 'dashboard'
            namespace = 'spud_admin'
        }
	}
}
