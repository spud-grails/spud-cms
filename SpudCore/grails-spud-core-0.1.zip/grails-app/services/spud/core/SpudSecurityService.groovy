package spud.core

import grails.transaction.Transactional

@Transactional
class SpudSecurityService {

	def isAuthorized(spudSecureAnnotation, request, params) {
		return false
	}

	def getLoginUrl() {
		return [controller: 'session', action: 'login']
	}
}
