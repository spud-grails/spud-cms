class SpudCoreUrlMappings {

	static mappings = {
        '/spud/admin' {
            controller = 'dashboard'
            action = 'index'
            namespace = 'spud_admin'
        }
	}
}
