window.tinyMCEPreInit = {base: "/SpudDemo/assets/tiny_mce", suffix:''};
